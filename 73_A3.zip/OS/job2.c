#include <stdio.h>
int main(){
    // for(int i=0;i<5;i++){
        printf("I am Job_2\n");
    // }
    return  0;
}